﻿using KingGambit;
namespace KingGambit
{
    public class King
    {
        public string Name { get; }

        private readonly List<IDefender> defenders;

        public King(string name)
        {
            Name = name;
            defenders = new List<IDefender>();
        }

        public void AddDefender(IDefender defender)
        {
            defender.Died += DefenderDiedHandler;
            defenders.Add(defender);
        }

        private void DefenderDiedHandler(object sender, EventArgs e)
        {
            IDefender defender = sender as IDefender;
            if (defender != null)
            {
                defenders.Remove(defender);
            }
        }

        public void UnderAttack()
        {
            Console.WriteLine($"King {Name} is under attack!");
            foreach (var guard in defenders.OfType<RoyalGuard>())
            {
                guard.RespondToAttack();
            }

            foreach (var footman in defenders.OfType<Footman>())
            {
                footman.RespondToAttack();
            }
        }

        public void Kill(string name)
        {
            IDefender defender = defenders.FirstOrDefault(d => d.Name == name);
            defender?.TakeHit();
        }
    }
}