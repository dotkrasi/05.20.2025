﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace KingGambit
{

    public interface IDefender
    {
        string Name { get; }
        event EventHandler Died;
        void RespondToAttack();
        void TakeHit();
    }

}
