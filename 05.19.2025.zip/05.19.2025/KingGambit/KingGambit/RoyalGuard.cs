﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KingGambit
{
    public class RoyalGuard : IDefender
    {
        private int hitsTaken = 0;
        public string Name { get; }

        public event EventHandler Died;

        public RoyalGuard(string name)
        {
            Name = name;
        }

        public void RespondToAttack()
        {
            Console.WriteLine($"Royal Guard {Name} is defending!");
        }

        public void TakeHit()
        {
            hitsTaken++;
            if (hitsTaken >= 3)
            {
                Died?.Invoke(this, EventArgs.Empty);
            }
        }
    }
}
