﻿using KingGambit;

public class Program
{
    public static void Main()
    {
        string kingName = Console.ReadLine();
        var guardNames = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var footmanNames = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

        var king = new King(kingName);

        foreach (var guard in guardNames)
        {
            king.AddDefender(new RoyalGuard(guard));
        }

        foreach (var footman in footmanNames)
        {
            king.AddDefender(new Footman(footman));
        }

        string command;
        while ((command = Console.ReadLine()) != "End")
        {
            if (command == "Attack King")
            {
                king.UnderAttack();
            }
            else if (command.StartsWith("Kill "))
            {
                var name = command.Split()[1];
                king.Kill(name);
            }
        }
    }
}   