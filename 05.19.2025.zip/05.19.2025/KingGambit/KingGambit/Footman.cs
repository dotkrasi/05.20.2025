﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KingGambit
{
    public class Footman : IDefender
    {
        private int hitsTaken = 0;
        public string Name { get; }

        public event EventHandler Died;

        public Footman(string name)
        {
            Name = name;
        }

        public void RespondToAttack()
        {
            Console.WriteLine($"Footman {Name} is panicking!");
        }

        public void TakeHit()
        {
            hitsTaken++;
            if (hitsTaken >= 2)
            {
                Died?.Invoke(this, EventArgs.Empty);
            }
        }
    }
}
