﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy
{
    public class SubtractionStrategy : ICalculationStrategy
    {
        public int Calculate(int a, int b) => a - b;
    }
}
