﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy
{
    public class PrimitiveCalculator
    {
        private ICalculationStrategy strategy;

        public PrimitiveCalculator()
        {
            this.strategy = new AdditionStrategy(); // по подразбиране
        }

        public void ChangeStrategy(char @operator)
        {
            switch (@operator)
            {
                case '+':
                    this.strategy = new AdditionStrategy();
                    break;
                case '-':
                    this.strategy = new SubtractionStrategy();
                    break;
                case '*':
                    this.strategy = new MultiplicationStrategy();
                    break;
                case '/':
                    this.strategy = new DivisionStrategy();
                    break;
                default:
                    throw new InvalidOperationException("Invalid operator");
            }
        }

        public int PerformCalculation(int firstOperand, int secondOperand)
        {
            return this.strategy.Calculate(firstOperand, secondOperand);
        }
    }
}
