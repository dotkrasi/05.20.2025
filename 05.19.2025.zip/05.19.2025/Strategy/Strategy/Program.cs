﻿using Strategy;
using System;

public class Program
{
    public static void Main()
    {
        PrimitiveCalculator calculator = new PrimitiveCalculator();

        string input;
        while ((input = Console.ReadLine()) != "End")
        {
            if (input.StartsWith("mode"))
            {
                char newOperator = input.Split()[1][0];
                calculator.ChangeStrategy(newOperator);
            }
            else
            {
                var parts = input.Split();
                int a = int.Parse(parts[0]);
                int b = int.Parse(parts[1]);
                try
                {
                    int result = calculator.PerformCalculation(a, b);
                    Console.WriteLine(result);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
        }
    }
}
