﻿using JobExercise;
using System;
using System.Collections.Generic;

public class Program
{
    public static void Main()
    {
        Dictionary<string, IEmployee> employees = new();
        List<Job> jobs = new();

        string input;
        while ((input = Console.ReadLine()) != "End")
        {
            string[] parts = input.Split();

            switch (parts[0])
            {
                case "StandartEmployee":
                    employees[parts[1]] = new StandartEmployee(parts[1]);
                    break;

                case "PartTimeEmployee":
                    employees[parts[1]] = new PartTimeEmployee(parts[1]);
                    break;

                case "Job":
                    string jobName = parts[1];
                    int hours = int.Parse(parts[2]);
                    string empName = parts[3];
                    if (employees.ContainsKey(empName))
                    {
                        jobs.Add(new Job(jobName, hours, employees[empName]));
                    }
                    break;

                case "Pass":
                    List<Job> finishedJobs = new();
                    foreach (var job in jobs)
                    {
                        job.Update();
                        if (job.IsDone)
                        {
                            finishedJobs.Add(job);
                        }
                    }

                    foreach (var job in finishedJobs)
                    {
                        jobs.Remove(job);
                    }
                    break;

                case "Status":
                    foreach (var job in jobs)
                    {
                        Console.WriteLine(job);
                    }
                    break;
            }
        }
    }
}
