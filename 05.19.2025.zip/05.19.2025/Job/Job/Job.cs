﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobExercise
{
    public class Job
    {
        public string Name { get; }
        public int HoursRequired { get; private set; }
        public IEmployee Employee { get; }

        public bool IsDone => HoursRequired <= 0;

        public Job(string name, int hoursRequired, IEmployee employee)
        {
            Name = name;
            HoursRequired = hoursRequired;
            Employee = employee;
        }

        public void Update()
        {
            HoursRequired -= Employee.WorkHoursPerWeek;
            if (HoursRequired <= 0)
            {
                Console.WriteLine($"Job {Name} done!");
            }
        }

        public override string ToString()
        {
            return $"Job: {Name} Hours Remaining: {HoursRequired}";
        }
    }

}
