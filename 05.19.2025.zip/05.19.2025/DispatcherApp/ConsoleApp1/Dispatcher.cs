﻿using System;

namespace DispatcherApp
{
    public delegate void NameChangeEventHandler(object sender, NameChangeEventArgs args);

    public class Dispatcher
    {
        private string name;

        public event NameChangeEventHandler NameChange;

        public string Name
        {
            get => name;
            set
            {
                name = value;
                OnNameChange(new NameChangeEventArgs(value));
            }
        }

        protected void OnNameChange(NameChangeEventArgs args)
        {
            if (this.NameChange != null)
            {
                this.NameChange(this, args);
            }
        }
    }
}
