﻿using System;
using System.Linq;

namespace RoyalBattle
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string kingName = Console.ReadLine();
            var guardNames = Console.ReadLine().Split();
            var footmanNames = Console.ReadLine().Split();

            King king = new King(kingName);

            // Добавяме охранители
            foreach (var name in guardNames)
            {
                king.AddDefender(new RoyalGuard(name));
            }

            // Добавяме слуги
            foreach (var name in footmanNames)
            {
                king.AddDefender(new Footman(name));
            }

            while (true)
            {
                string input = Console.ReadLine();

                if (input == "End")
                    break;

                string[] tokens = input.Split();

                if (tokens[0] == "Attack" && tokens[1] == "King")
                {
                    king.Attack();
                }
                else if (tokens[0] == "Kill")
                {
                    string nameToKill = tokens[1];
                    king.RemoveDefender(nameToKill);
                }
            }
        }
    }
}
