﻿using System;

namespace RoyalBattle
{
    public class Footman : IDefender
    {
        public string Name { get; private set; }

        public Footman(string name)
        {
            Name = name;
        }

        public void RespondToAttack()
        {
            Console.WriteLine($"Footman {Name} is panicking!");
        }
    }
}
