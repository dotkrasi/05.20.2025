﻿namespace RoyalBattle
{
    public interface IDefender
    {
        string Name { get; }
        void RespondToAttack();
    }
}
