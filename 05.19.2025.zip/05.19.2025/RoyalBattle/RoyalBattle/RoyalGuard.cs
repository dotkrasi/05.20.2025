﻿using System;

namespace RoyalBattle
{
    public class RoyalGuard : IDefender
    {
        public string Name { get; private set; }

        public RoyalGuard(string name)
        {
            Name = name;
        }

        public void RespondToAttack()
        {
            Console.WriteLine($"Royal Guard {Name} is defending!");
        }
    }
}
