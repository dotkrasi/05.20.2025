﻿using System;
using System.Collections.Generic;

namespace RoyalBattle
{
    public class King
    {
        public string Name { get; private set; }

        private List<IDefender> defenders;

        public King(string name)
        {
            Name = name;
            defenders = new List<IDefender>();
        }

        public void AddDefender(IDefender defender)
        {
            defenders.Add(defender);
        }

        public void RemoveDefender(string name)
        {
            defenders.RemoveAll(d => d.Name == name);
        }

        public void Attack()
        {
            Console.WriteLine($"King {Name} is under attack!");

            foreach (var guard in defenders)
            {
                guard.RespondToAttack();
            }
        }
    }
}
