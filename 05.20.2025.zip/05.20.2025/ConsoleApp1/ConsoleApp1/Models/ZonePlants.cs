﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Models
{
    public class ZonePlants
    {

        [Key] public int Id { get; set; }

        [ForeignKey(nameof(Zones))]
        [Required] public int ZoneId { get; set; }
        Zones Zones = new Zones();

        [ForeignKey(nameof(PlantSpecies))]
        public int PlantId { get; set; }
        PlantSpecies PlantSpecies = new PlantSpecies();

        [Required] public int Density { get; set; }

    }
}
