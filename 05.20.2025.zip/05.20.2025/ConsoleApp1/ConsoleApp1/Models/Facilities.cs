﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Models
{
    public class Facilities
    {

        [Key] public int Id { get; set; }

        [ForeignKey(nameof(Zones))]
        [Required] public int ZoneId { get; set; }
        Zones Zones = new Zones();

        [Required] public string Type { get; set; }

        [Required] public string Material { get; set; }

        [Required] public string Condition { get; set; }

        [Required] public string InstalledOn { get; set; }

    }
}
